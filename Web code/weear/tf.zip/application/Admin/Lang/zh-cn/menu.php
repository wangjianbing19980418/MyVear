<?php
return array(
		"APP" => '应用',
		"NAME" => '菜单名称',
		"ADD_SUB_MENU" => '添加子菜单'
);